# Architecture fonctionnelle MAGNISA

## Chaîne métier principale

Client → Service → Devis → Acceptation → Facture → Paiement → Trésorerie → Comptabilité → Reporting → Analyse.

Une facture peut aussi être créée directement.

## Domaines

- **Ventes** : clients, prospects, services, devis, factures, avoirs, paiements.
- **Achats/charges** : fournisseurs, dépenses et coûts directs.
- **Trésorerie** : banque, caisse, Mobile Money, chèques, transferts et rapprochements.
- **Comptabilité** : écritures, lignes comptables, catégories normalisées et états dérivés.
- **Fiscalité & social** : obligations paramétrables, échéances et paiements ; aucun taux légal n'est figé dans le code.
- **Pilotage** : tableau de bord, budgets, prévisions, analyse intelligente et recommandations.
- **Administration** : organisation, utilisateurs, rôles, paramètres, modèles et audit.

## Invariants

1. Toutes les données métier sont rattachées à une `organization_id`.
2. Une ligne enfant appartient à la même organisation que son document parent.
3. Les numéros sont produits par une séquence transactionnelle et portent une contrainte d'unicité par organisation.
4. Les montants monétaires sont stockés en `numeric(18,2)`.
5. Les écritures comptables validées sont équilibrées : somme débit = somme crédit.
6. Les documents validés et opérations financières ne sont jamais supprimés silencieusement.
7. Les statuts sont des conséquences d'actions réelles et non des valeurs décoratives.

## Analyse intelligente

Le moteur d'analyse est séparé du calcul. Les ratios et seuils sont calculés de manière déterministe ; une couche de rédaction IA peut être ajoutée plus tard, mais ne doit jamais inventer les chiffres.
