# Parcours d'acceptation

## Parcours nominal

1. Créer un compte avec une adresse `@proton.me` ou `@protonmail.com`.
2. Vérifier l'e-mail.
3. Créer l'organisation et ses paramètres.
4. Créer un compte financier.
5. Créer un client.
6. Créer un service.
7. Créer un devis avec plusieurs lignes.
8. Vérifier les calculs HT, remise, taxes, TTC.
9. Prévisualiser et générer le PDF.
10. Accepter le devis.
11. Convertir le devis accepté en facture sans ressaisie.
12. Émettre la facture.
13. Enregistrer un paiement partiel ; vérifier `partially_paid` et le reste dû.
14. Enregistrer le solde ; vérifier `paid`.
15. Vérifier le mouvement du compte financier et la baisse de la créance.
16. Vérifier le tableau de bord, l'audit et l'analyse.

## Cas particuliers obligatoires

- Base totalement vide : aucun chiffre fictif.
- Facture directe sans devis.
- Client sans e-mail : pas de bouton d'e-mail prétendument fonctionnel.
- Remise 0 à 100 %, quantité positive, prix non négatif.
- Plusieurs paiements sur une facture.
- Paiement supérieur au reste dû : refus.
- Facture échue avec solde : statut `overdue` calculé.
- Annulation : confirmation, motif et audit.
- Chèque reçu : compte `cheque_clearing`, pas banque disponible avant encaissement.
- Transfert interne : deux mouvements opposés, aucun CA/charge.
- Doublon de numéro : impossible par contrainte et verrou de séquence.
