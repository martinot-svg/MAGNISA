# Déploiement MAGNISA — Vercel + Supabase

## 1. Environnements

Créer au minimum :

- un projet Supabase de développement ;
- un projet Supabase de production ;
- un projet Vercel relié au dépôt Git ;
- des variables d'environnement séparées pour Preview et Production.

Ne jamais tester une migration nouvelle directement sur la base de production.

## 2. Base de données

Exécuter les fichiers de `supabase/migrations` dans l'ordre numérique.

Après migration :

1. vérifier les contraintes ;
2. vérifier les politiques RLS ;
3. créer un compte test ;
4. créer deux organisations distinctes ;
5. confirmer qu'un utilisateur de l'organisation A ne peut jamais lire une ressource de B.

## 3. Variables Vercel

Variables obligatoires :

- `NEXT_PUBLIC_APP_URL`
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `EMAIL_CODE_SECRET`

Pour Gmail provisoire :

- `EMAIL_PROVIDER=gmail_smtp`
- `GMAIL_SMTP_USER`
- `GMAIL_APP_PASSWORD`

Pour un domaine d'envoi professionnel :

- `EMAIL_PROVIDER=resend`
- `RESEND_API_KEY`
- `EMAIL_FROM`

Ne jamais préfixer une clé secrète par `NEXT_PUBLIC_`.

## 4. Vérification e-mail

Le flux MAGNISA est :

1. création de l'utilisateur non confirmé ;
2. génération aléatoire d'un code à 4 chiffres ;
3. stockage uniquement du hash ;
4. expiration après 5 minutes ;
5. maximum 5 essais ;
6. renvoi autorisé après 60 secondes ;
7. confirmation du compte via service-role uniquement après code correct.

## 5. Stockage logo

Le bucket `organization-branding` est créé par migration. Les uploads sont préfixés par l'UUID de l'organisation. Les politiques d'upload exigent l'appartenance à l'organisation.

## 6. Déploiement Vercel

Après push Git :

1. importer le dépôt dans Vercel ;
2. renseigner les variables ;
3. lancer un Preview Deployment ;
4. tester inscription, vérification, onboarding et opérations métier ;
5. seulement ensuite promouvoir en production.

## 7. Mise à jour après déploiement

Pour corriger MAGNISA après déploiement :

1. créer une branche Git ;
2. modifier le code ;
3. ajouter une migration si le schéma change ;
4. tester sur l'environnement de développement ;
5. ouvrir une pull request/revue ;
6. laisser Vercel générer une Preview ;
7. tester ;
8. fusionner vers la branche de production.

Les anciennes migrations ne doivent pas être réécrites après application en production. Ajouter une nouvelle migration corrective.
