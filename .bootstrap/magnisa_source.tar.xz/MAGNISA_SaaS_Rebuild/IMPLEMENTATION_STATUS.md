# MAGNISA — État d'implémentation

Ce document évite toute confusion entre une fonctionnalité réellement implémentée et une fonction encore à finaliser. Une page visible ne doit jamais être considérée comme « terminée » uniquement parce qu'elle existe visuellement.

## Implémenté ou renforcé dans cette version

### Produit & identité
- Logo officiel intégré au produit.
- Nouvelle landing page premium, loader logo, animation et mode reduced-motion.
- Design system visuel consolidé et responsive.
- Icônes vectorielles, pas d'emoji d'interface.

### Authentification
- Inscription Gmail ou domaine professionnel selon la politique MAGNISA actuelle.
- Refus de plusieurs domaines personnels/disposables connus.
- Vérification par code à 4 chiffres : 5 minutes, 5 essais, renvoi 60 secondes, nouveau code invalidant l'ancien.
- Hash HMAC du code côté serveur.
- Envoi réel via Gmail SMTP ou Resend selon configuration.
- Connexion, déconnexion, mot de passe oublié et changement de mot de passe.

### Multi-entreprise & administration
- `organization_id` sur les données métier.
- RLS Supabase.
- Upload réel du logo dans Supabase Storage.
- Slogan et couleurs d'entreprise.
- Catalogue de fonctionnalités activables/désactivables par entreprise.
- Conservation des données lorsqu'un module est désactivé.
- Rôles étendus et couche de permissions serveur avec overrides possibles.
- Audit des flux pris en charge.

### Commercial
- Prospects, clients, services.
- Projets/missions.
- Devis et lignes de devis.
- Acceptation et versionnement déjà présents dans le socle.
- Conversion devis accepté → commande transactionnelle.
- Commande → facture transactionnelle.
- Facture directe ou issue d'un flux précédent.
- Paiements clients partiels / multiples selon les RPC existantes.

### Achats & finance
- Fournisseurs et sous-traitants.
- Factures fournisseurs.
- Paiement fournisseur transactionnel avec impact trésorerie.
- Dépenses.
- Banque, caisse et Mobile Money.
- Transferts internes.
- Dettes & engagements consolidés.
- Comptes associés.
- Emprunts.

### Personnel & Paie
- Salariés.
- Périodes de paie.
- Bulletins avec éléments de rémunération et retenues saisis sans taux réglementaires codés en dur.
- Validation du bulletin.
- Paiement partiel/complet via compte financier, avec impact trésorerie.

### Fiscalité, pilotage & comptabilité
- Obligations fiscales et sociales enregistrables.
- Budgets et scénarios existants.
- Dashboard avec graphiques basés sur les données réelles.
- Analyse économique enrichie : lecture économique, explication simple, risque, recommandation et encouragement justifié.
- Base comptable à double entrée pour les opérations déjà prises en charge.
- États financiers internes simplifiés.

### Documents
- Logo et slogan sur documents.
- Couleurs du modèle.
- NIF, STAT, RCS configurables.
- Coordonnées bancaires et mentions.
- Montant total en lettres : « Arrêtée la présente facture… » / « Arrêté le présent devis… ».
- Affichage du payé et du reste dû sur facture lorsque pertinent.
- Génération PDF réelle.

## À finaliser avant d'annoncer une couverture 100 % du cahier des charges

Les points ci-dessous ne doivent pas être présentés comme entièrement terminés :

- Éditeur visuel avancé avec placement libre des blocs par drag-and-drop.
- Snapshot immuable complet du template et des données légales au moment de l'émission de chaque document.
- Interface complète des avoirs, remboursements et application aux créances.
- Bons de livraison et reçus avec leurs propres workflows/document templates.
- Workflow complet des chèques : dépôt, encaissement, rejet, contrepassation et frais éventuels.
- Rapprochement bancaire avec import de relevés et rapprochement semi-automatique.
- Affectation d'un paiement client unique à plusieurs factures et écran d'encaissements non affectés.
- Comptabilité légale complète : plan comptable juridictionnel, immobilisations/amortissements, régularisations, clôture robuste et contrepassations généralisées.
- États financiers réglementaires et annexe conformes à une juridiction précise.
- Moteur fiscal/social réglementaire versionné par date après validation des règles locales actuelles.
- Paie réglementaire automatique : barèmes et plafonds doivent être validés par juridiction avant automatisation.
- Matrice UI complète des permissions granulaires et seuils d'approbation.
- Séparation des tâches formalisée sur tous les flux sensibles.
- Recherche globale, pagination et filtres uniformisés partout.
- Pièces justificatives privées sur tous les modules.
- Notifications planifiées/background jobs pour échéances, relances et récurrences.
- Facturation récurrente / abonnements et jalons complexes.
- E-mails devis/factures avec pièce jointe via fournisseur mail/API et preuve d'envoi.
- Suite E2E automatisée exécutée contre Supabase/Vercel réels.
- Revue complète WCAG, tests multi-navigateurs réels et audit de performance.

## Validation effectuée dans l'environnement de génération

- Analyse syntaxique TypeScript/TSX effectuée sur les fichiers de `src` et `middleware.ts` : aucune erreur de parsing détectée au dernier passage.
- Vérification que toutes les routes visibles dans la sidebar possèdent une page correspondante.
- Aucune donnée métier de démonstration n'est insérée dans la base.
- `npm install` a été tenté dans l'environnement de génération mais a expiré ; un `next build` intégral n'a donc pas pu être exécuté ici.
- Les migrations doivent être testées sur un projet Supabase de développement avant production.

## Règle de mise en production

Ne déclarer MAGNISA prêt pour production qu'après : installation complète, exécution des migrations sur une base dédiée, configuration des secrets, tests d'intégration et E2E, revue RLS/RBAC, validation comptable/fiscale adaptée à la juridiction, sauvegardes, observabilité, test de restauration et test de charge raisonnable.
